R code for project on integer identification constraints for ordinal CFA.

To replicate the simulation reported in the manuscript, run the `simulation_execute.R` file to execute all steps of the simulation study. Check/update the `n.cores` value to match your number of cores/CPUs.

For any bugs, please contact Sonja D. Winter (sdwinter\@missouri.edu)
